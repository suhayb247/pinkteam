document.querySelectorAll(".help-button").forEach(button => {
    button.addEventListener("click", function() {
        window.location.href = "https://www.example-help-website-parking.com/help";
    });
});